# Upwork Freelancer - Portfolio

Hi, welcome to my portfolio project 👋

This project was built using _Next JS_, _Tailwind CSS_, _TypeScript_ and _Framer motion_.

View the portfolio at [lekipising.com](https://lekipising.com)

Design inspired by this [Figma Project](https://www.figma.com/file/B4tWUAi7mBTWZdR0wWB9Oi/Portfolio-for-Developers?type=design&node-id=0%3A1&t=aNHvHZhiOyfYqyul-1)
